#!/bin/bash 


# Go home
region="us-east-2"
aws configure set default.region $region


# Create multiple instances to load balance

ami="ami-08962a4068733a2b6"

instanceType="t3.micro"

targetGroupArn=`cat targetGroupArn.txt`
loadBalancerArn=`cat loadBalancerArn.txt`
vpcId=`cat vpcId.txt`
keyName=`cat keyName.txt`
securityGroupId=`cat securityGroupId.txt`
publicDNS1=`cat publicDNS1.txt`
publicDNS2=`cat publicDNS2.txt`
publicDNS3=`cat publicDNS3.txt`


# Define user data
IFS='' read -r -d '' userData <<EOF
#!/bin/bash
sudo apt-get update
sudo apt-get install python3-pip -y
sudo apt-get install python3-flask -y
cd /home/ubuntu
curl "https://raw.githubusercontent.com/dekeldex/Exercise2-Caching/main/app.py" > app.py
echo -n $targetGroupArn > targetGroupArn.txt
echo -n $loadBalancerArn > loadBalancerArn.txt
pip3 install ec2-metadata
pip3 install boto3
pip3 install jump-consistent-hash
pip3 install xxhash

nohup flask run --host 0.0.0.0
EOF

echo "$userData"

# Placement
availabilityZones=$(aws ec2 describe-availability-zones)
availabilityZone=$(echo "$availabilityZones" \
  | jq -r ".AvailabilityZones[1].ZoneName")
echo $availabilityZone

placement="AvailabilityZone=$availabilityZone,Tenancy=default"
echo $placement


# Launch 1 default linux instances in the default vpc
instances=$(aws ec2 run-instances \
  --image-id $ami \
  --count 1 \
  --key-name $keyName \
  --security-group-ids $securityGroupId \
  --associate-public-ip-address \
  --instance-type $instanceType \
  --user-data "$userData" \
  --placement $placement \
  --iam-instance-profile Name="ec2FullAccess" \
  )

instanceId1=$(echo $instances \
  | jq -r '.Instances | .[0] | .InstanceId')

echo $instanceId1

aws ec2 wait instance-running \
  --instance-ids $instanceId1

aws ec2 describe-instances \
  --instance-ids $instanceId1 \
  | jq -r ".Reservations[].Instances[].State"

publicDNS1=$(aws ec2 describe-instances \
  --instance-ids $instanceId1 \
  | jq -r ".Reservations[].Instances[0].NetworkInterfaces[].Association.PublicDnsName")



aws elbv2 register-targets \
  --target-group-arn $targetGroupArn \
  --targets Id=$instanceId1

curl "http://$publicDNS1:5000/newNodeAdded"
curl "http://$publicDNS2:5000/newNodeAdded"
curl "http://$publicDNS3:5000/newNodeAdded"

echo "please wait 2 minutes before making requests so that everything will be setup :)"