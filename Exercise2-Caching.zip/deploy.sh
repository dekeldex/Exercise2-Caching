#!/bin/bash 


# Go home
region="us-east-2"
aws configure set default.region $region

# Create a key pair
keyName="ec2-alb-$region"
echo $keyName

AWS_ROLE="ec2-full-access"

echo "Creating role $AWS_ROLE..."
aws iam create-role --role-name $AWS_ROLE --assume-role-policy-document file://trust-policy.json

aws iam attach-role-policy --role-name $AWS_ROLE  \
    --policy-arn arn:aws:iam::aws:policy/AmazonEC2FullAccess


echo "Wait for role creation"

aws iam wait role-exists --role-name $AWS_ROLE
aws iam get-role --role-name $AWS_ROLE
ARN_ROLE=$(aws iam get-role --role-name $AWS_ROLE | jq -r .Role.Arn)

aws iam create-instance-profile --instance-profile-name "ec2FullAccess"

aws iam add-role-to-instance-profile --instance-profile-name "ec2FullAccess" --role-name $AWS_ROLE

# WIP to avoid error when key exists
#if [$(aws ec2 describe-key-pairs --filter  'Name=key-name,Values=$keyName' | jq '.KeyPairs | length==0')]
  aws ec2 create-key-pair \
    --key-name $keyName \
    | jq -r ".KeyMaterial" > ./$keyName.pem
#fi

chmod 400 ./$keyName.pem

# Create a security group 
securityGroupId=$(aws ec2 create-security-group \
  --description "This ALB SG allows traffic only on port 80 and port 5000 and 22" \
  --group-name "CachingInTheCloud" \
  | jq -r .GroupId)
echo $securityGroupId

myIp=$(curl ipinfo.io/ip)
myCidr="$myIp/32"
allCidr="0.0.0.0/0"

aws ec2 authorize-security-group-ingress \
  --group-id $securityGroupId \
  --protocol tcp \
  --port 5000 \
  --cidr $allCidr
aws ec2 authorize-security-group-ingress \
  --group-id $securityGroupId \
  --protocol tcp \
  --port 22 \
  --cidr $allCidr
aws ec2 authorize-security-group-ingress \
  --group-id $securityGroupId \
  --protocol tcp \
  --port 80 \
  --cidr $allCidr
aws ec2 describe-security-groups \
  --group-ids $securityGroupId \
  | jq -r ".SecurityGroups[].GroupId"

# Get VPC and Subnet Ids
vpcId=$(aws ec2 describe-vpcs \
  --filter "Name=isDefault,Values=true" \
  | jq -r ".Vpcs | .[] | .VpcId")
echo $vpcId

subnet1=$(aws ec2 describe-subnets \
  --filter "Name=vpc-id,Values=$vpcId" \
  | jq -r ".Subnets | .[0] | .SubnetId")
subnet2=$(aws ec2 describe-subnets \
  --filter "Name=vpc-id,Values=$vpcId" \
  | jq -r ".Subnets | .[1] | .SubnetId")

echo $subnet1, $subnet2

echo $keyName, $securityGroupId, $myIp, $myCidr, $vpcId, $subnet1, $subnet2

echo -n $vpcId > vpcId.txt
echo -n $keyName > keyName.txt
echo -n $securityGroupId > securityGroupId.txt

# Create multiple instances to load balance

ami="ami-08962a4068733a2b6"

instanceType="t3.micro"


targetGroupArn=$(aws elbv2 create-target-group \
  --name my-targets \
  --protocol HTTP \
  --port 5000 \
  --vpc-id $vpcId \
  --health-check-path "/healthCheck" \
  --health-check-interval-seconds 10 \
  --healthy-threshold-count 2 \
  --health-check-port 5000 \
  | jq -r ".TargetGroups[].TargetGroupArn")

loadBalancer=$(aws elbv2 create-load-balancer \
  --name my-application-load-balancer \
  --subnets $subnet1 $subnet2 \
  --security-groups $securityGroupId)

loadBalancerArn=$(echo "$loadBalancer" \
  | jq -r ".LoadBalancers[].LoadBalancerArn")
  

echo -n $targetGroupArn > targetGroupArn.txt
echo -n $loadBalancerArn > loadBalancerArn.txt

# Define user data
IFS='' read -r -d '' userData <<EOF
#!/bin/bash
sudo apt-get update
sudo apt-get install python3-pip -y
sudo apt-get install python3-flask -y
cd /home/ubuntu
curl "https://raw.githubusercontent.com/dekeldex/Exercise2-Caching/main/app.py" > app.py
echo -n $targetGroupArn > targetGroupArn.txt
echo -n $loadBalancerArn > loadBalancerArn.txt
pip3 install ec2-metadata
pip3 install boto3
pip3 install jump-consistent-hash
pip3 install xxhash

nohup flask run --host 0.0.0.0
EOF

echo "$userData"

# Placement
availabilityZones=$(aws ec2 describe-availability-zones)
availabilityZone=$(echo "$availabilityZones" \
  | jq -r ".AvailabilityZones[1].ZoneName")
echo $availabilityZone

placement="AvailabilityZone=$availabilityZone,Tenancy=default"
echo $placement


# Launch 3 default linux instances in the default vpc
instances=$(aws ec2 run-instances \
  --image-id $ami \
  --count 3 \
  --key-name $keyName \
  --security-group-ids $securityGroupId \
  --associate-public-ip-address \
  --instance-type $instanceType \
  --user-data "$userData" \
  --placement $placement \
  --iam-instance-profile Name="ec2FullAccess" \
  )

instanceId1=$(echo $instances \
  | jq -r '.Instances | .[0] | .InstanceId')
instanceId2=$(echo $instances \
  | jq -r '.Instances | .[1] | .InstanceId')
instanceId3=$(echo $instances \
  | jq -r '.Instances | .[2] | .InstanceId')

echo $instanceId1, $instanceId2 , $instanceId3

aws ec2 wait instance-running \
  --instance-ids $instanceId1 $instanceId2 $instanceId3

aws ec2 describe-instances \
  --instance-ids $instanceId1 $instanceId2 $instanceId3 \
  | jq -r ".Reservations[].Instances[].State"

publicDNS1=$(aws ec2 describe-instances \
  --instance-ids $instanceId1 $instanceId2 $instanceId3 \
  | jq -r ".Reservations[].Instances[0].NetworkInterfaces[].Association.PublicDnsName")
publicDNS2=$(aws ec2 describe-instances \
  --instance-ids $instanceId1 $instanceId2 $instanceId3 \
  | jq -r ".Reservations[].Instances[0].NetworkInterfaces[].Association.PublicDnsName")
publicDNS3=$(aws ec2 describe-instances \
  --instance-ids $instanceId1 $instanceId2 $instanceId3 \
  | jq -r ".Reservations[].Instances[0].NetworkInterfaces[].Association.PublicDnsName")

echo -n $publicDNS1 > publicDNS1.txt
echo -n $publicDNS2 > publicDNS2.txt
echo -n $publicDNS3 > publicDNS3.txt


loadBalancerDns=$(echo "$loadBalancer" \
  | jq -r ".LoadBalancers[].DNSName")

echo "loadBalancerDns:"
echo $loadBalancerDns


aws elbv2 register-targets \
  --target-group-arn $targetGroupArn \
  --targets Id=$instanceId1 Id=$instanceId2 Id=$instanceId3

listenerArn=$(aws elbv2 create-listener \
  --load-balancer-arn $loadBalancerArn \
  --protocol HTTP \
  --port 80 \
  --default-actions Type=forward,TargetGroupArn=$targetGroupArn \
  | jq -r ".Listeners[].ListenerArn")

echo "please wait 2 minutes before making requests so that everything will be setup :)"